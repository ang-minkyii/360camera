#command history

 1884  reset
 1885  cd /home/workspace
 1886  cd home/workspace
 1887  cd x/home/workspace
 1888  ls
 1889  cd workspace
 1890  ls
 1891  cd OpenCV
 1892  ls
 1893  cd opencv
 1894  ls
 1895  mkdir build
 1896  cd build
 1897  cmake -D CMAKE_BUILD_TYPE=RELEASE -D CMAKE_INSTALL_PREFIX=/usr/local -D WITH_TBB=ON -D BUILD_NEW_PYTHON_SUPPORT=ON -D WITH_V4L=ON -D INSTALL_C_EXAMPLES=ON -D INSTALL_PYTHON_EXAMPLES=ON -D BUILD_EXAMPLES=ON -D WITH_QT=ON -D WITH_OPENGL=ON ..
 1898  make
 1899  sudo make install
 1900  cd ~
 1901  ls
 1902  cd workspace/OpenCV
 1903  ls
 1904  cd opencv
 1905  ls
 1906  cd build
 1907  cmake -D CMAKE_BUILD_TYPE=RELEASE -D CMAKE_INSTALL_PREFIX=/usr/local ..
 1908  make clean
 1909  make uninstall
 1910  cd -
 1911  ls
 1912  mkdir build
 1913  cd build
 1914  cmake -D CMAKE_BUILD_TYPE=RELEASE -D CMAKE_INSTALL_PREFIX=/usr/local ..
 1915  make
 1916  sudo make install
 1917  opencv --version
 1918  cd -
 1919  ls
 1920  cd -
 1921  ls
 1922  cd -
 1923  ls
 1924  cd -
 1925  cd /home/x/workspace/OpenCV
 1926  ls
 1927  python test.py
 1928  lsusb -t
 1929  sudo apt-get install v4l-utils
 1930  v4l2-ctl --list-devices
 1931  v4l2-ctl -d /dev/video0 --list-formats
 1932  python test.py
 1933  cd /workspace
 1934  cd workspace
 1935  ls
 1936  cd OpenCV
 1937  ls
 1938  python test.py
 1939  v4l2-ctl -d /dev/video0 --list-formats-ext
 1940  ./sublime_text
 1941  python test.py
 1942  reset
 1943  python test.py
 1944  reset

 1951  v4l2-ctl -V
 1952  v4l2-ctl --set-fmt-video=width=1280,height=720,pixelformat=1

 1959  v4l2-ctl -V

 1971  reset
 1972  python test.py
 1973  v4l2-ctl -V
 1974  v4l2-ctl --set-fmt-video=width=640,height=480,pixelformat=1
 1975  v4l2-ctl -V
 1976  python test.py
 1977  v4l2-ctl -V
 1978  python test.py
 1979  cd workspace
 1980  cd OpenCV
 1981  python test.py
 1982  history n
 1983  history 100


sudo tee /sys/module/usbcore/parameters/usbfs_memory_mb >/dev/null <<<0
