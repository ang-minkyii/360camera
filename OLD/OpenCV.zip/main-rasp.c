//#include "stdafx.h"

#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>

int main(  )
{
    IplImage* pFrame1 = NULL;
    IplImage* pFrame2 = NULL;
    IplImage* pFrame3 = NULL;
    IplImage* final=cvCreateImage(cvSize(300,300), IPL_DEPTH_8U,3);
    IplImage* final1=cvCreateImage(cvSize(600,400), IPL_DEPTH_8U,3);

    int R=340;
    int r=510;
    int pdc=8;
    int pdc1=-10;
    int min1=481;
    int max1=521;
    int min2=118;
    int max2=158;
    int min3=580;
    int max3=600;
    int min4=30;
    int max4=53;
    int x=600;
    int y=50;
    int i,j;

    CvScalar s;
    CvScalar s1;
    CvScalar s2;

    CvCapture* pCapture1 = cvCreateCameraCapture(2);
    CvCapture* pCapture2 = cvCreateCameraCapture(1);
    CvCapture* pCapture3 = cvCreateCameraCapture(0);


    cvSetCaptureProperty( pCapture1, CV_CAP_PROP_FRAME_WIDTH , 640 );
    cvSetCaptureProperty( pCapture1, CV_CAP_PROP_FRAME_HEIGHT , 480 );
    cvSetCaptureProperty( pCapture1, CV_CAP_PROP_FPS , 15 );
    cvSetCaptureProperty( pCapture2, CV_CAP_PROP_FRAME_WIDTH , 640 );
    cvSetCaptureProperty( pCapture2, CV_CAP_PROP_FRAME_HEIGHT , 480 );
    cvSetCaptureProperty( pCapture2, CV_CAP_PROP_FPS , 15 );
    cvSetCaptureProperty( pCapture3, CV_CAP_PROP_FRAME_WIDTH , 640 );
    cvSetCaptureProperty( pCapture3, CV_CAP_PROP_FRAME_HEIGHT , 480 );
    cvSetCaptureProperty( pCapture3, CV_CAP_PROP_FPS , 15 );
    cvNamedWindow("Panoramic Video", 0);
            while(1)
            {
                if (x<181) {
                    pFrame1=cvQueryFrame( pCapture1 );
                    for(i=0;i<300;i++){
                        for(j=0;j<300;j++){
                            int i1=i+y+30-pdc;
                            int j1=(j+x-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame1,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    pFrame1=NULL;
                }
                else if ((x>=181)&&(x<221)){
                    pFrame1=cvQueryFrame( pCapture1 );
                    pFrame2=cvQueryFrame( pCapture2 );
                    for(i=0;i<300;i++){
                        for(j=0;j<(481-x);j++){
                            int i1=i+y+30-pdc;
                            int j1=(j+x-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame1,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=481-x;j<300;j++){
                            int i1=i+y+30-pdc;
                            int i2=i+y+30;
                            int j1=(j+x-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            int j2=(j+x-min1+min2-310)*sqrt(R*R-(i2-240)*(i2-240))/(R+r-sqrt(r*r-(i2-240)*(i2-240)))+320;
                            double a=j+x-min1;
                            double b=max1-j-x;
                            double c=max1-min1;
                            s=cvGet2D(pFrame1,i1,j1);
                            s1=cvGet2D(pFrame2,i2,j2);
                            s2.val[0]=a/c*s1.val[0]+b/c*s.val[0];
                            s2.val[1]=a/c*s1.val[1]+b/c*s.val[1];
                            s2.val[2]=a/c*s1.val[2]+b/c*s.val[2];
                            s2.val[3]=a/c*s1.val[3]+b/c*s.val[3];
                            cvSet2D(final,i,j,s2);
                        }
                    }
                    pFrame1=NULL;
                    pFrame2=NULL;
                }
                else if ((x>=221)&&(x<481)) {

                    pFrame1=cvQueryFrame( pCapture1 );
                    pFrame2=cvQueryFrame( pCapture2 );
                    for(i=0;i<300;i++){
                        for(j=0;j<(481-x);j++){
                            int i1=i+y+30-pdc;
                            int j1=(j+x-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame1,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=481-x;j<(521-x);j++){
                            int i1=i+y+30-pdc;
                            int i2=i+y+30;
                            int j1=(j+x-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            int j2=(j+x-min1+min2-310)*sqrt(R*R-(i2-240)*(i2-240))/(R+r-sqrt(r*r-(i2-240)*(i2-240)))+320;
                            double a=(j+x)-min1;
                            double b=max1-j-x;
                            double c=max1-min1;
                            s=cvGet2D(pFrame1,i1,j1);
                            s1=cvGet2D(pFrame2,i2,j2);
                            s2.val[0]=a/c*s1.val[0]+b/c*s.val[0];
                            s2.val[1]=a/c*s1.val[1]+b/c*s.val[1];
                            s2.val[2]=a/c*s1.val[2]+b/c*s.val[2];
                            s2.val[3]=a/c*s1.val[3]+b/c*s.val[3];
                            cvSet2D(final,i,j,s2);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=521-x;j<300;j++){
                            int i1=i+y+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame2,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    pFrame1=NULL;
                    pFrame2=NULL;
                }
                else if((x>=481)&&(x<521)) {
                    pFrame1=cvQueryFrame( pCapture1 );
                    pFrame2=cvQueryFrame( pCapture2 );
                    for(i=0;i<300;i++){
                        for(j=0;j<(521-x);j++){
                            int i1=i+y+30-pdc;
                            int i2=i+y+30;
                            int j1=(j+x-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            int j2=(j+x-min1+min2-310)*sqrt(R*R-(i2-240)*(i2-240))/(R+r-sqrt(r*r-(i2-240)*(i2-240)))+320;
                            double a=(j+x)-min1;
                            double b=max1-(j+x);
                            double c=max1-min1;
                            s=cvGet2D(pFrame1,i1,j1);
                            s1=cvGet2D(pFrame2,i2,j2);
                            s2.val[0]=a/c*s1.val[0]+b/c*s.val[0];
                            s2.val[1]=a/c*s1.val[1]+b/c*s.val[1];
                            s2.val[2]=a/c*s1.val[2]+b/c*s.val[2];
                            s2.val[3]=a/c*s1.val[3]+b/c*s.val[3];
                            cvSet2D(final,i,j,s2);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=521-x;j<300;j++){
                            int i1=i+y+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame2,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                pFrame1=NULL;
                pFrame2=NULL;
                }
                else if ((x>=521)&&(x<643)){

                    pFrame2=cvQueryFrame( pCapture2 );
                    for(i=0;i<300;i++){
                        for(j=0;j<300;j++){
                            int i1=i+y+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame2,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    pFrame2=NULL;
                }
                else if ((x>=643)&&(x<663)){

                    pFrame2=cvQueryFrame( pCapture2 );
                    pFrame3=cvQueryFrame( pCapture3 );
                    for(i=0;i<300;i++){
                        for(j=0;j<(943-x);j++){
                            int i1=i+y+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame2,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=943-x;j<300;j++){
                            int i1=i+y+30;
                            int i2=i+y+pdc1+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            int j2=(j+x-max1+max2-min3+min4-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            double a=(j+x)-min3-max1+max2;
                            double b=max3+max1-max2-(j+x);
                            double c=max3-min3;
                            s=cvGet2D(pFrame2,i1,j1);
                            s1=cvGet2D(pFrame3,i2,j2);
                            s2.val[0]=a/c*s1.val[0]+b/c*s.val[0];
                            s2.val[1]=a/c*s1.val[1]+b/c*s.val[1];
                            s2.val[2]=a/c*s1.val[2]+b/c*s.val[2];
                            s2.val[3]=a/c*s1.val[3]+b/c*s.val[3];
                            cvSet2D(final,i,j,s2);
                        }
                    }
                    pFrame3=NULL;
                    pFrame2=NULL;
                }
                else if ((x>=663)&&(x<943)){
                    pFrame2=cvQueryFrame( pCapture2 );
                    pFrame3=cvQueryFrame( pCapture3 );
                    for(i=0;i<300;i++){
                        for(j=0;j<(943-x);j++){
                            int i1=i+y+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame2,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=943-x;j<(963-x);j++){
                            int i1=i+y+30;
                            int i2=i+y+pdc1+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            int j2=(j+x-max1+max2-min3+min4-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            double a=(j+x)-min3-max1+max2;
                            double b=max3+max1-max2-(j+x);
                            double c=max3-min3;
                            s=cvGet2D(pFrame2,i1,j1);
                            s1=cvGet2D(pFrame3,i2,j2);
                            s2.val[0]=a/c*s1.val[0]+b/c*s.val[0];
                            s2.val[1]=a/c*s1.val[1]+b/c*s.val[1];
                            s2.val[2]=a/c*s1.val[2]+b/c*s.val[2];
                            s2.val[3]=a/c*s1.val[3]+b/c*s.val[3];
                            cvSet2D(final,i,j,s2);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=963-x;j<300;j++){
                            int i1=i+y+pdc1+30;
                            int j1=(j+x-max3-max1+max2+max4-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame3,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    pFrame3=NULL;
                    pFrame2=NULL;
                }
                else if ((x>=943)&&(x<963)){
                    pFrame2=cvQueryFrame( pCapture2 );
                    pFrame3=cvQueryFrame( pCapture3 );
                    for(i=0;i<300;i++){
                        for(j=0;j<(963-x);j++){
                            int i1=i+y+30;
                            int i2=i+y+pdc1+30;
                            int j1=(j+x-max1+max2-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            int j2=(j+x-max1+max2-min3+min4-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            double a=(j+x)-min3-max1+max2;
                            double b=max3+max1-max2-(j+x);
                            double c=max3-min3;
                            s=cvGet2D(pFrame2,i1,j1);
                            s1=cvGet2D(pFrame3,i2,j2);
                            s2.val[0]=a/c*s1.val[0]+b/c*s.val[0];
                            s2.val[1]=a/c*s1.val[1]+b/c*s.val[1];
                            s2.val[2]=a/c*s1.val[2]+b/c*s.val[2];
                            s2.val[3]=a/c*s1.val[3]+b/c*s.val[3];
                            cvSet2D(final,i,j,s2);
                        }
                    }
                    for(i=0;i<300;i++){
                        for(j=963-x;j<300;j++){
                            int i1=i+y+pdc1+30;
                            int j1=(j+x-max3-max1+max2+max4-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame3,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    pFrame3=NULL;
                    pFrame2=NULL;

                }
                else {
                    pFrame3=cvQueryFrame( pCapture3 );
                    for(i=0;i<300;i++){
                        for(j=0;j<300;j++){
                            int i1=i+y+pdc1+30;
                            int j1=(j+x-max3-max1+max2+max4-310)*sqrt(R*R-(i1-240)*(i1-240))/(R+r-sqrt(r*r-(i1-240)*(i1-240)))+320;
                            s=cvGet2D(pFrame3,i1,j1);
                            cvSet2D(final,i,j,s);
                        }
                    }
                    pFrame3=NULL;
                }
                cvShowImage("Panoramic Video",final);
                char c=cvWaitKey(15);
                if (c==119){
                    y=y-20;
                }
                else if (c==115){
                    y=y+20;
                }
                else if (c==97){
                    x=x-20;
                }
                else if (c==100){
                    x=x+20;
                }
                else if (c==27){
                    break;
                }

                if (x<0) x=0;
                if (y<0) y=0;
                if(x>1250) x=1250;
                if(y>110) y=110;
            }pi ra

    cvReleaseCapture(&pCapture1);
    cvReleaseCapture(&pCapture2);
    cvReleaseCapture(&pCapture3);
    cvDestroyWindow("Panoramic Video");
    return 0;
}
